package jsint;
import java.io.PrintWriter;

/**
    This is just a shadow class so that code using jsint.SI will still
    work.  The preferred method is to use the Class jscheme.JS.
 **/
public class SI extends jscheme.JS {

}    
