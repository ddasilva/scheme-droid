;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; JScheme version of the Gabriel benchmarks
;; USAGE:  java -jar lib/jscheme.jar using/gabriel/runbenchmark.sch '(runall)'
;; Modified: 5/27/2004, TJH
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;