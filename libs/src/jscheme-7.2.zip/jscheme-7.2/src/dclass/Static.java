package dclass;
public class Static extends Item {
  public Static (Object item) { this.item = item; }
  public Object getbody () { return item; }
}
