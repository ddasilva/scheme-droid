package dclass;
public class Import extends Item {
  public Import(Object item) { super(item); }
  public Object getPackage () { return item; }
}
