package dclass;
public class Package extends Item {
  public Package(Object item) { super(item); }
  public Object getName () { return item; }
}
