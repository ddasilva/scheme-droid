There are several jars in this folder 

One from Sun
  javax.servlet.jar

Two from apache
jasper-compiler.jar
jasper-runtime.jar

Two from are from jetty.mortbay.org, whose license is in jetty-license.txt
org.mortbay.jetty.jar
org.mortbay.jmx.jar
